package model;

public class Follower {
	
	protected String name;
	
	protected Channel[] channels;
	protected int noc; // no of channels;
	
	
	public Follower(String name, int maxChannels) {
		this.name = name;
		this.channels = new Channel[maxChannels];
		this.noc = 0;
	}
	
	public void follow(Channel c) {
		this.channels[this.noc] = c;
		this.noc++;
	}
	
	public void unfollow(String name) {
		boolean found = false;
		for(int i=0; !found && i<this.noc; i++){
			if(this.channels[i].getName().equals(name)) {
				for(int j=i; j<this.noc; j++) {
					this.channels[j] = channels[j+1];
				}
			this.noc--;
			found= true;
			}
		}
	}
	
	public String listOfChannels() {
		String listOfChannels = "[";
		for(int i=0; i<this.noc; i++) {
			listOfChannels += channels[i].getName();
			if(i<this.noc-1) {
				listOfChannels+=", ";
			}
		}
		listOfChannels+="]";
		
		return listOfChannels;
	}
		
	
}

package model;

public class Subscriber extends Follower {

	private String[] recommendedVideos;
	private int nor; // no of recommended videos

	public Subscriber(String name, int maxChannels, int maxRecommendedVideos) {
		super(name, maxChannels);

		this.recommendedVideos = new String[maxRecommendedVideos];
		this.nor = 0;
	}

	public void addRecommendedVideo(String name) {
		this.recommendedVideos[this.nor] = name;
		this.nor++;
	}

	public void watch(String videoName, int watchTime) {
		for(int i=0; i<noc; i++) {
			Channel c = channels[i];
			
			for(int j=0; j<c.getVideosCount(); j++) {
				if(c.getReleasedVideos()[j].equals(videoName)) {
					
					for(int k=0; k<c.getFollowersCount(); k++) {
						Follower f = c.getFollowers()[k];
						if(f instanceof Monitor) {
							
							((Monitor) f ).addStats(watchTime,c.getName());
						}
					}
				}
			}
		}
	}

	public String toString() {
		String result = "";

		String recommendedVideoList = "<";
		for(int i=0; i<this.nor; i++) {
			recommendedVideoList+= this.recommendedVideos[i];
			if(i<this.nor -1) {
				recommendedVideoList+=", ";
			}
		}

		recommendedVideoList+=">";

		if(this.noc==0 && this.nor==0) {
			result= String.format("Subscriber %s follows no channels and has no recommended videos.", name);
		}
		else if(this.noc!=0 && this.nor==0) {
			result= String.format("Subscriber %s follows %s and has no recommended videos.", name, listOfChannels());
		}
		else if(this.noc!=0 && this.nor!=0) {
			result = String.format("Subscriber %s follows %s and is recommended %s.", name, listOfChannels(), recommendedVideoList );
		}

		return result;


	}


}

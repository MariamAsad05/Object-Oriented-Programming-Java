package model;

public class Monitor extends Follower {

	private boolean[] initialized;
	private int[] views;
	private int[] totalWatchTime;
	private int[] maxWatchTime;

	public Monitor(String name, int maxChannels) {
		super(name, maxChannels);

		this.initialized = new boolean[maxChannels];
		this.maxWatchTime = new int[maxChannels];
		this.totalWatchTime = new int[maxChannels];
		this.views = new int[maxChannels];
	}

	public void addStats(int watchTime, String channelName) {
		int index =-1;
		for(int i=0; i<this.noc; i++) {
			if(this.channels[i].getName().equals(channelName)) {
				index =i;
			}
		}

		if(index>=0) {
			this.initialized[index] = true;
			this.views[index]++;
			this.totalWatchTime[index]+=watchTime;
			if(watchTime>this.maxWatchTime[index]) {
				this.maxWatchTime[index] = watchTime;
			}
		}
	}
	
	public String listOfChannel() {
		String listOfChannels = "";
		
		listOfChannels+="[";
		for(int i=0; i<this.noc; i++) {
			listOfChannels += channels[i].getName();
			if(this.views[i] >0) {
				double avgTime = (double) this.totalWatchTime[i]/this.views[i];
				listOfChannels+= String.format(" {#views: %d, max watch time: %d, avg watch time: %.2f}",this.views[i], this.maxWatchTime[i], avgTime);
			}
			if(i<this.noc-1) {
				listOfChannels+=", ";
			}
		}
		listOfChannels+="]";
		
		return listOfChannels;
	}


	public String toString() {
		String result = "";


		if(this.noc==0) {
			result = String.format("Monitor %s follows no channels.", name);
		}
		else {
			result = String.format("Monitor %s follows %s.", name, listOfChannel());
		}

		return result;
	}
}

package model;



public class Channel {

	private String channelName;
	private String[] releasedVideos;
	private int nov; //no of released videos
	
	private Follower[] followers; //polymorphic array
	private int nof; //no of followers


	public Channel(String name, int maxFollowers, int maxReleasedVideos) {
		this.channelName = name;
		
		this.releasedVideos = new String[maxReleasedVideos];
		this.nov = 0;
		
		this.followers = new Follower[maxFollowers];
		this.nof = 0;
	}
	
	public String getName() {
		return this.channelName ;
	}
	
	public int getVideosCount() {
		return this.nov ;
	}
	
	public String[] getReleasedVideos() {
		return this.releasedVideos;
	}
	
	public int getFollowersCount() {
		return this.nof;
	}
	
	public Follower[] getFollowers() {
		return this.followers ;
	}

	public void releaseANewVideo(String videoName) {
		this.releasedVideos[this.nov]= videoName;
		this.nov++;
		
		for (int i=0; i<this.nof; i++) {
			Follower f= this.followers[i];
			if(f instanceof Subscriber) {
				((Subscriber) f).addRecommendedVideo(videoName);
			}
		}
	}
	
	public void follow(Follower f) {
		this.followers[this.nof] = f;
		this.nof++;
		
		f.follow(this);
	}
	
	public void unfollow(Follower f) {
		boolean found = false;
		for(int i=0; !found && i<this.nof; i++){
			if(this.followers[i] == f) {
				for(int j=i; j<this.nof; j++) {
					this.followers[j] = followers[j+1];
				}
			this.nof--;
			found= true;
			
			}
		}
		
		f.unfollow(this.channelName);
		
	}


	public String toString() {
		String result="";
		
		String listOfVideos="<";
		for(int i=0; i<this.nov ; i++) {
			listOfVideos += this.releasedVideos[i];
			if(i < this.nov-1) {
				listOfVideos+=", ";
			}
		}
		
		listOfVideos+=">";
		
		String listOfFollowers="[";
		for(int i=0; i<this.nof; i++) {
			String type = null;
			 Follower f = this.followers[i];
			if(f instanceof Subscriber) {
				type = "Subscriber";
			}
			else if(f instanceof Monitor) {
				type = "Monitor";
			}
			
			listOfFollowers+= type + " " + f.name;
			if(i<this.nof -1) {
				listOfFollowers+=", ";
			}
		}
		listOfFollowers+="]";

		if(this.nov==0 && this.nof==0) {
			result = String.format("%s released no videos and has no followers.", this.channelName);
		}
		else if(this.nov!=0 && this.nof==0) {
			result = String.format("%s released %s and has no followers.", this.channelName,listOfVideos);
		}
		else if(this.nov==0 && this.nof!=0) {
			result = String.format("%s released no videos and is followed by %s.", this.channelName,listOfFollowers);
		}
		else{
			result = String.format("%s released %s and is followed by %s.",this.channelName, listOfVideos, listOfFollowers);
		}
		return result;
	}

}

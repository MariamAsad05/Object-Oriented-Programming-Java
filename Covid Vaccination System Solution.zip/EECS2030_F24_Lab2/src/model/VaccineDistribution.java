package model;

public class VaccineDistribution {
	
	private Vaccine vaccine;
	private int noOfDoses;
	private String status;
	
	public VaccineDistribution(Vaccine v, int dose) {
		this.vaccine = v;
		this.noOfDoses = dose;
		
		this.status = String.format("%d doses of %s by %s",this.noOfDoses, this.vaccine.getCodeName(), this.vaccine.getManufacturer());
	}
	
	public Vaccine getVaccine() {
		return this.vaccine ;
	}
	
	public int getNumberofDoses() {
		return this.noOfDoses ;
	}
	
	public void setNumberOfDoses(int doses) {
		this.noOfDoses = doses;
	}
	
	public String toString() {
		return this.status ;
		
	}

}

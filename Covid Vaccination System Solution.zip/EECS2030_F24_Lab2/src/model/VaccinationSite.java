package model;

public class VaccinationSite {

	private String name;
	private VaccineDistribution[] distribution;
	private int nod; //no of distributions
	private final int MAX_NUM_OF_DIST = 4;
	private int maxSupply;
	private HealthRecord[] appointments ;
	private int noa; //no of appointments
	private final int MAX_NUM_OF_APPOINTMENTS = 200;


	public VaccinationSite(String name, int maxSupply) {
		this.name = name;
		this.distribution = new VaccineDistribution[this.MAX_NUM_OF_DIST];
		this.nod = 0;
		this.maxSupply = maxSupply;
		this.appointments = new HealthRecord[this.MAX_NUM_OF_APPOINTMENTS];
		this.noa = 0;
	}

	public void addDistribution(Vaccine v, int noOfDoses) throws UnrecognizedVaccineCodeNameException, TooMuchDistributionException{
		boolean b1 = v.approvedVaccines(v.getCodeName());
		boolean b2= this.getNumberOfAvailableDoses() + noOfDoses>this.maxSupply;

		if (!b1) {
			throw new UnrecognizedVaccineCodeNameException("Error: ....");
		}
		else if(b2) {
			throw new TooMuchDistributionException("Error:...");
		}
		else {
			boolean found = false;
			int index =-1;
			for (int i=0; !found && i<this.nod; i++) {
				if (this.distribution[i].getVaccine().getCodeName().equals(v.getCodeName())) {
					found = true;
					index = i;
				}
			}
			if(index<0) {
				this.distribution[this.nod] = new VaccineDistribution(v, noOfDoses);
				this.nod++;
			}
			else {
				VaccineDistribution existing = this.distribution[index];
				existing.setNumberOfDoses(existing.getNumberofDoses() + noOfDoses);
			}
		}
	}


	public void bookAppointment(HealthRecord patient) throws InsufficientVaccineDosesException{

		boolean a = (this.getNumberOfAvailableDoses() - this.noa) == 0 ;

		if(a) {
			patient.setAppointmentStatus(String.format("Last vaccination appointment for %s with %s failed", patient.getPatientName(), this.name));
			throw new InsufficientVaccineDosesException("Error:...");
		}
		else {
			this.appointments[this.noa] = patient;
			this.noa++;
			patient.setAppointmentStatus(String.format("Last vaccination appointment for %s with %s succeeded", patient.getPatientName(), this.name));
		}

	}
	
	private VaccineDistribution getFirstDistribution() {
		VaccineDistribution vd = null;
		boolean found = false;
		
		
		for(int i=0; !found && i<this.nod; i++) {
			if(this.distribution[i].getNumberofDoses()>0) {
				found = true;
				vd = this.distribution[i];
			}
		}
		return vd;
	}
	
	public void administer(String date) {
		
		for(int i=0; i<this.noa; i++) {
			HealthRecord patient = this.appointments[i];
			
			// update on site 
			VaccineDistribution vd = this.getFirstDistribution();
			vd.setNumberOfDoses(vd.getNumberofDoses()-1);
			
			//update on patient
			patient.addRecord(vd.getVaccine(), this.name, date);
			
			
		}
		this.appointments = new HealthRecord[this.MAX_NUM_OF_APPOINTMENTS];
		this.noa = 0;
		
	}



	public int getNumberOfAvailableDoses(){
		int total = 0;
		for(int i=0; i<this.nod; i++) {
			total+= this.distribution[i].getNumberofDoses();
		}
		return total;
	}

	public int getNumberOfAvailableDoses(String vaccineCodeName) {

		int noOfDoses =0;
		boolean found = false;

		for(int i=0; !found && i<this.nod; i++) {
			if(this.distribution[i].getVaccine().getCodeName().equals(vaccineCodeName)) {
				noOfDoses = this.distribution[i].getNumberofDoses();
				found = true;
			}
		}

		return noOfDoses;
	}

	public String toString() {
		String result = "";

		String list ="<";

		//North York General Hospital has 5 available doses: <3 doses of Moderna, 2 doses of Pfizer/BioNTech>
		for(int i=0; i<this.nod; i++) {
			VaccineDistribution vd = this.distribution[i];
			list+= String.format("%d doses of %s", vd.getNumberofDoses(), vd.getVaccine().getManufacturer());
			if(i<this.nod -1) {
				list+=", ";
			}
		}


		list += ">";

		result = String.format("%s has %d available doses: %s",this.name, this.getNumberOfAvailableDoses(), list);

		return result ;
	}

}

package model;

@SuppressWarnings("serial")
public class InsufficientVaccineDosesException extends Exception {
	
	public InsufficientVaccineDosesException (String s) {
		super(s);
	}

}

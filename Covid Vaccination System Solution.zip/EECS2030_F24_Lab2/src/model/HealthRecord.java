package model;

public class HealthRecord {

	private String patientName;
	private int noi; //no of items in the three arrays (index position)
	private Vaccine[] vaccines;
	private String[] dates;
	private String[] sites;
	private final int MAX_SIZE_OF_DATA_COLLECTION;
	private String appointmentStatus;


	public HealthRecord(String name, int maxDoses) {
		this.patientName = name;
		this.MAX_SIZE_OF_DATA_COLLECTION = maxDoses;
		this.vaccines = new Vaccine[this.MAX_SIZE_OF_DATA_COLLECTION];
		this.dates = new String[this.MAX_SIZE_OF_DATA_COLLECTION];
		this.sites = new String[this.MAX_SIZE_OF_DATA_COLLECTION];
		this.noi = 0;
		this.appointmentStatus = null;
	}

	public void addRecord(Vaccine v, String site, String date) {
		this.vaccines[this.noi] = v;
		this.sites[this.noi] = site;
		this.dates[this.noi] = date;
		this.noi++;

	}
	
	public String getPatientName() {
		return this.patientName ;
	}
	
	public void setAppointmentStatus(String status) {
		this.appointmentStatus = status;
	}
	

	public String getVaccinationReceipt() {
		String result = "";

		if(this.noi == 0) {
			result = String.format("%s has not yet received any doses.", this.patientName );
		}
		else {
			String list="";
			list="[";
			for (int i=0; i<this.noi; i++) {
				list += String.format("%s in %s on %s", this.vaccines[i].toString(), this.sites[i], this.dates[i]);
				if(i <this.noi-1) {
					list+="; ";
				}	
			}
			list+="]";
			result = String.format("Number of doses %s has received: %d %s",this.patientName, this.noi, list) ;
		}
		return result;
	}

	public String getAppointmentStatus() {
		
		String result="";

		if (this.appointmentStatus == null) {
			result = String.format("No vaccination appointment for %s yet", this.patientName);
		}
		else {
			result = this.appointmentStatus ;
		}
		return result;
	}


}

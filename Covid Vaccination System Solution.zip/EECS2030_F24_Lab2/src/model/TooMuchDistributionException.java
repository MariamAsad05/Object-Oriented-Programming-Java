package model;

@SuppressWarnings("serial")
public class TooMuchDistributionException extends Exception {
	
	public TooMuchDistributionException(String s) {
		super(s);
	}

}

package model;

public class Vaccine {
	
	private String codeName;
	private String type;
	private String manufacturer;
	
	private String status;
	
	
	public boolean approvedVaccines(String code) {
		boolean exists = false;
		String[] listOfApprpvedVaccines = {"mRNA-1273", "BNT162b2", "Ad26.COV2.S", "AZD1222"};
		
		for (int i=0; i<listOfApprpvedVaccines.length && !exists; i++) {
			if(listOfApprpvedVaccines[i].equals(code)) {
				exists = true;
			}
		}
		
		return exists;
	}
	
	
	public Vaccine(String codeName, String type, String manufacturer) {
		this.codeName = codeName;
		this.type = type;
		this.manufacturer = manufacturer;
		
		if(this.approvedVaccines(codeName)) {
			this.status = String.format("Recognized vaccine: %s (%s; %s)",this.codeName, this.type, this.manufacturer);
		}
		else {
			this.status = String.format("Unrecognized vaccine: %s (%s; %s)",this.codeName, this.type, this.manufacturer);
		}
	}
	
	public String getCodeName() {
		return this.codeName;
	}
	
	public String getManufacturer() {
		return this.manufacturer ;
	}
	
	
	public String toString() {
		return this.status ;
	}

}

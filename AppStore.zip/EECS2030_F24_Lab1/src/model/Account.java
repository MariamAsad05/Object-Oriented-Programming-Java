package model;

public class Account {

	private String accountName;
	private AppStore store;
	private String[] downloadApps;
	private int noa; //no of download apps
	private final int MAX_NUM_OF_DOWNLOAD_APPS = 50;
	private String status;


	public Account(String name, AppStore store) {
		this.accountName = name;
		this.store = store;

		this.downloadApps = new String[MAX_NUM_OF_DOWNLOAD_APPS];
		this.noa =0;

		this.status ="";

		this.status = String.format("An account linked to the %s store is created for %s.", this.store.getBranch(),this.accountName);

	}

	public String[] getNamesOfDownloadedApps() {
		String[] names = new String[this.noa];

		for(int i=0; i<this.noa;i++) {
			names[i] = this.downloadApps[i];
		}

		return names ;
	}

	public App[] getObjectsOfDownloadedApps() {
		App[] apps = new App[this.noa];

		for(int i=0; i<this.noa; i++) {
			String nameOfApp = this.downloadApps[i];
			App a = this.getApp(nameOfApp);
			apps[i] = a;
		}

		return apps;
	}

	public App getApp(String nameOfApp) {

		return this.store.getApp(nameOfApp);
	}
	
	public boolean appExists(String appName) {
		boolean nameExists = false;
		for (int i=0; i<noa && !nameExists; i++) {
			if (this.downloadApps[i].equals(appName)) {
				nameExists = true;
			}
		}
		return nameExists;
	}

	public void download(String appName) {
		
		boolean appExists = this.appExists(appName);

		
		if(appExists) {
			this.status = String.format("Error: %s has already been downloaded for %s.", appName, this.accountName);
		}
		else {
			this.downloadApps[this.noa] = appName;
			this.noa++;

			this.status = String.format("%s is successfully downloaded for %s.", appName, this.accountName);
		}

	}

	public void uninstall(String name) {
		boolean found = false;
		for (int i=0; i < this.noa && !found; i++) {
			if(this.downloadApps[i].equals(name)) {
				for (int j=i; j<this.noa; j++) {
					this.downloadApps[j]= this.downloadApps[j+1];
				}
				this.noa--;
				found = true;
			}
		}
		
		if(found) {
			this.status = String.format("%s is successfully uninstalled for %s.", name, this.accountName);
		}
		else {
			this.status = String.format("Error: %s has not been downloaded for %s.", name, this.accountName);
		}
	}

	public void submitRating(String name, int score) {
		boolean appExists = this.appExists(name);
		
		if(!appExists) {
			this.status = String.format("Error: %s is not a downloaded app for %s.", name, this.accountName );
		}
		else {
			this.getApp(name).submitRating(score);
			this.status = String.format("Rating score %d of %s is successfully submitted for %s.", score, this.accountName, name );
		}
	}

	public void switchStore(AppStore store) {
		this.store = store;
		this.status = String.format("Account for Suyeon is now linked to the %s store.", this.store.getBranch());
	}


	public String toString() {

		return this.status;
	}

}

package model;

public class AppStore {
	
	private String branch;
	private App[] apps;
	private int index;
	
	public AppStore(String name, int maxApps) {
		this.branch = name;
		this.apps = new App[maxApps];
		this.index =0;
	}
	
	public String getBranch() {
		return this.branch ;
	}
	
	public App getApp(String name) {
		App app = null;
		boolean found = false;
		for (int i=0; i<this.index && !found; i++) {
			App a = this.apps[i];
			if(a.getName().equals(name)){
				app = a;
				found=true;
			}
		}
		return app;
	}

	public String[] getStableApps(int noOfUpdates) {
		String[] sa = new String[this.index];
		int count =0;
		String s= "";
		
		for(int i=0; i<this.index; i++) {
			App a= this.apps[i];
			if(a.getUpdateHistory().length>= noOfUpdates) {
				s = String.format("%s (%d versions; Current Version: %s)", a.getName(),a.getUpdateHistory().length,a.getWhatIsNew());
				sa[count] = s;
				count++;
			}
		}
		
		String[] stableAppsPrecise = new String[count];
		for (int i=0; i<count; i++) {
			stableAppsPrecise[i] = sa[i];
		}
		
		return stableAppsPrecise;
	}
	
	public void addApp(App a) {
		this.apps[index] = a;
		this.index ++;
	}
	
	

}
